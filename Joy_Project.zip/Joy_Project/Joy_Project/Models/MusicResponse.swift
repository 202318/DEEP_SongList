//
//  MusicResponse.swift
//  Joy_Project
//
//  Created by etud on 09/06/2026.
//
import Foundation

struct MusicResponse: Codable {
    let results: [Song]
}
