//
//  AudioSong.swift
//  Joy_Project
//
//  Created by etud on 09/06/2026.
//

import Foundation

struct AudioSong: Identifiable, Codable, SongProtocol {
    let id: UUID
    let title: String
    let artist: String
    let duration: Int
    let genre: MusicGenre
    let audioURL: String

    func displayInfo() {
        print("Audio - \(title) by \(artist)")
    }
    func getAuthor() -> String { return artist }
    func getPlayingTime() -> Int { return duration }
}
