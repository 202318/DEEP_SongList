//
//  Genre.swift
//  Joy_Project
//
//  Created by etud on 08/06/2026.
//
import Foundation

enum MusicGenre: String, Codable {
    case pop = "Pop"
    case rock = "Rock"
    case jazz = "Jazz"
    case hipHop = "Hip Hop"
    case classical = "Classical"
}
