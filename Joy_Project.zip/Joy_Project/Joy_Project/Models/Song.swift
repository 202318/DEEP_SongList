//
//  Song.swift
//  Joy_Project
//
//  Created by etud on 08/06/2026.
//

import Foundation

struct Song: Identifiable, Codable, SongProtocol {
    let id: UUID
    let title: String
    let artist: String
    let duration: Int
    let genre: MusicGenre
    let from: String
    let artworkURL: String

    func displayInfo() {
        print("Title: \(title), Artist: \(artist), Duration: \(duration)s")
    }
    func getAuthor() -> String { return artist }
    func getPlayingTime() -> Int { return duration }
}
