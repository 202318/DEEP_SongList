//
//  Playlist.swift
//  Joy_Project
//
//  Created by etud on 08/06/2026.
//
import Foundation

struct Playlist: PlaylistProtocol {
    var name: String
    var songs: [any SongProtocol]

    mutating func addSong(_ song: any SongProtocol) {
        songs.append(song)
    }
    mutating func removeSong(at index: Int) {
        guard index >= 0 && index < songs.count else { return }
        songs.remove(at: index)
    }
    mutating func removeSong(named title: String) {
        songs.removeAll { $0.title == title }
    }
    func totalDuration() -> Int {
        songs.reduce(0) { $0 + $1.duration }
    }
    func searchSong(byTitle title: String) -> (any SongProtocol)? {
        songs.first { $0.title.lowercased() == title.lowercased() }
    }
    func findSongs(byArtist artist: String) -> [any SongProtocol] {
        songs.filter { $0.artist.lowercased() == artist.lowercased() }
    }
    func averageSongDuration() -> Double {
        guard !songs.isEmpty else { return 0.0 }
        return Double(totalDuration()) / Double(songs.count)
    }
    func songCount() -> Int { songs.count }
}
