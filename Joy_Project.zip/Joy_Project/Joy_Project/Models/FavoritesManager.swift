//
//  FavoritesManager.swift
//  Joy_Project
//
//  Created by etud on 09/06/2026.
//

import Foundation

class FavoritesManager: ObservableObject {
    @Published var favorites: [Song] = []

    private let fileURL: URL = {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return docs.appendingPathComponent("favorites.json")
    }()

    init() { load() }

    func isFavorite(_ song: Song) -> Bool {
        favorites.contains { $0.title == song.title && $0.artist == song.artist }
    }

    func addFavorite(_ song: Song) {
        guard !isFavorite(song) else { return }
        favorites.append(song)
        save()
    }

    func removeFavorite(_ song: Song) {
        favorites.removeAll { $0.title == song.title && $0.artist == song.artist }
        save()
    }

    func remove(at offsets: IndexSet) {
        favorites.remove(atOffsets: offsets)
        save()
    }

    func move(from source: IndexSet, to destination: Int) {
        favorites.move(fromOffsets: source, toOffset: destination)
        save()
    }

    private func save() {
        if let data = try? JSONEncoder().encode(favorites) {
            try? data.write(to: fileURL)
        }
    }

    private func load() {
        guard let data = try? Data(contentsOf: fileURL),
              let saved = try? JSONDecoder().decode([Song].self, from: data)
        else { return }
        favorites = saved
    }
}
