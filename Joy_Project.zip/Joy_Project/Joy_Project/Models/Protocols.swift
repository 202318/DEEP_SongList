//
//  Protocols.swift
//  Joy_Project
//
//  Created by etud on 08/06/2026.
//

import Foundation

protocol SongProtocol {
    var title: String { get }
    var artist: String { get }
    var duration: Int { get }
    var genre: MusicGenre { get }
    
    func displayInfo()
    func getAuthor() -> String
    func getPlayingTime() -> Int
}

protocol PlaylistProtocol {
    var name: String { get set }
    var songs: [any SongProtocol] { get set }
    
    mutating func addSong(_ song: any SongProtocol)
    mutating func removeSong(at index: Int)
    mutating func removeSong(named title: String)
    
    func totalDuration() -> Int
    func searchSong(byTitle title: String) -> (any SongProtocol)?
    func findSongs(byArtist artist: String) -> [any SongProtocol]
    func averageSongDuration() -> Double
    func songCount() -> Int
    }

