//
//  MusicService.swift
//  Joy_Project
//
//  Created by etud on 09/06/2026.
//

import Foundation

class MusicService: ObservableObject {
    
    @Published var songs: [Song] = []
    @Published var isLoading = false

    func fetchSongs() {
        
        let urlString = "https://itunes.apple.com/search?term=rnb+amapiano&entity=song&limit=50"
        guard let url = URL(string: urlString) else {
            return
        }

        isLoading = true

        URLSession.shared.dataTask(with: url) { data, _, _ in
            
            DispatchQueue.main.async {
                
                self.isLoading = false
                
                guard let data = data,
                      let decoded = try? JSONDecoder().decode(
                        iTunesResponse.self,
                        from: data
                      )
                else {
                    return
                }

                self.songs = decoded.results.map { item in
                    Song(
                        id: UUID(),
                        title: item.trackName ?? "Unknown",
                        artist: item.artistName,
                        duration: (item.trackTimeMillis ?? 0) / 1000,
                        genre: MusicGenre(
                            rawValue: item.primaryGenreName ?? ""
                        ) ?? .pop,
                        from: item.previewUrl ?? "",
                        artworkURL: item.artworkUrl100 ?? ""
                    )
                }
            }
        }
        .resume()
    }

    func searchSongs(term: String) {
        
        guard !term.isEmpty else {
            fetchSongs()
            return
        }

        let encodedTerm =
            term.addingPercentEncoding(
                withAllowedCharacters: .urlQueryAllowed
            ) ?? ""

        let urlString =
            "https://itunes.apple.com/search?term=\(encodedTerm)&entity=song&limit=25"

        guard let url = URL(string: urlString) else {
            return
        }

        isLoading = true

        URLSession.shared.dataTask(with: url) { data, _, _ in

            DispatchQueue.main.async {

                self.isLoading = false

                guard let data = data,
                      let decoded = try? JSONDecoder().decode(
                        iTunesResponse.self,
                        from: data
                      )
                else {
                    return
                }

                self.songs = decoded.results.map { item in
                    Song(
                        id: UUID(),
                        title: item.trackName ?? "Unknown",
                        artist: item.artistName,
                        duration: (item.trackTimeMillis ?? 0) / 1000,
                        genre: MusicGenre(
                            rawValue: item.primaryGenreName ?? ""
                        ) ?? .pop,
                        from: item.previewUrl ?? "",
                        artworkURL: item.artworkUrl100 ?? ""
                    )
                }
            }
        }
        .resume()
    }

    func deleteSong(at offsets: IndexSet) {
        songs.remove(atOffsets: offsets)
    }
}

struct iTunesResponse: Codable {
    let results: [iTunesItem]
}

struct iTunesItem: Codable {
    let trackName: String?
    let artistName: String
    let trackTimeMillis: Int?
    let primaryGenreName: String?
    let previewUrl: String?
    let artworkUrl100: String?
}
