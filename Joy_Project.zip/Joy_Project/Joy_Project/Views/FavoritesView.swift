//
//  FavoritesView.swift
//  Joy_Project
//
//  Created by etud on 09/06/2026.
//

import SwiftUI

struct FavoritesView: View {
    @EnvironmentObject var favManager: FavoritesManager

    var body: some View {
        NavigationStack {
            Group {
                if favManager.favorites.isEmpty {
                    VStack(spacing: 16) {
                        Image(systemName: "heart.slash")
                            .font(.system(size: 60))
                            .foregroundColor(.gray)
                        Text("No favorites yet")
                            .font(.headline)
                            .foregroundColor(.secondary)
                        Text("Go to a song and tap Add to Favorites")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List {
                        ForEach(favManager.favorites) { song in
                            NavigationLink(destination: SongDetailView(song: song)) {
                                HStack(spacing: 12) {
                                    AsyncImage(url: URL(string: song.artworkURL)) { image in
                                        image.resizable().scaledToFill()
                                    } placeholder: {
                                        Color.gray.opacity(0.3)
                                    }
                                    .frame(width: 56, height: 56)
                                    .cornerRadius(8)
                                    .clipped()

                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(song.title)
                                            .font(.headline)
                                            .lineLimit(1)
                                        Text(song.artist)
                                            .font(.subheadline)
                                            .foregroundColor(.secondary)
                                            .lineLimit(1)
                                    }
                                }
                                .padding(.vertical, 4)
                            }
                        }
                        .onDelete(perform: favManager.remove)
                        .onMove(perform: favManager.move)
                    }
                    .listStyle(.plain)
                    .toolbar { EditButton() }
                }
            }
            .navigationTitle("Favorites")
        }
    }
}
