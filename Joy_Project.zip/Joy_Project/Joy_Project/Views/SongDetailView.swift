//
//  SongDetailView.swift
//  Joy_Project
//
//  Created by etud on 09/06/2026.
//
import SwiftUI
import AVKit
import AVFoundation

struct SongDetailView: View {
    let song: Song
    @EnvironmentObject var favManager: FavoritesManager
    @State private var player: AVPlayer?
    @State private var isPlaying = false
    @State private var currentTime: Double = 0
    @State private var totalDuration: Double = 0
    @State private var playbackTimer: Timer?

    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                AsyncImage(url: URL(string: song.artworkURL)) { image in
                    image.resizable().scaledToFit()
                } placeholder: {
                    Color.gray.opacity(0.2)
                }
                .frame(width: 220, height: 220)
                .cornerRadius(16)
                .shadow(radius: 8)

                VStack(spacing: 8) {
                    Text(song.title)
                        .font(.title2)
                        .bold()
                        .multilineTextAlignment(.center)
                    Text(song.artist)
                        .font(.title3)
                        .foregroundColor(.secondary)
                    Text(song.genre.rawValue)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }

                // Progress bar
                VStack(spacing: 4) {
                    Slider(value: $currentTime, in: 0...max(totalDuration, 1)) { editing in
                        if !editing {
                            player?.seek(to: CMTime(seconds: currentTime, preferredTimescale: 600))
                        }
                    }
                    .accentColor(.blue)

                    HStack {
                        Text(formatTime(currentTime))
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Spacer()
                        Text(formatTime(totalDuration))
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                .padding(.horizontal)

                // Playback controls
                HStack(spacing: 40) {
                    Button {
                        let newTime = max(currentTime - 10, 0)
                        player?.seek(to: CMTime(seconds: newTime, preferredTimescale: 600))
                        currentTime = newTime
                    } label: {
                        Image(systemName: "backward.fill")
                            .font(.system(size: 28))
                            .foregroundColor(.primary)
                    }

                    Button {
                        if isPlaying {
                            player?.pause()
                            playbackTimer?.invalidate()
                            isPlaying = false
                        } else {
                            if player == nil {
                                guard let url = URL(string: song.from) else { return }
                                let newPlayer = AVPlayer(url: url)
                                player = newPlayer
                                let asset = AVAsset(url: url)
                                Task {
                                    if let dur = try? await asset.load(.duration) {
                                        totalDuration = dur.seconds
                                    }
                                }
                            }
                            player?.play()
                            startTimer()
                            isPlaying = true
                        }
                    } label: {
                        ZStack {
                            Circle()
                                .fill(Color.blue)
                                .frame(width: 64, height: 64)
                            Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                                .font(.system(size: 26))
                                .foregroundColor(.white)
                        }
                    }

                    Button {
                        let newTime = min(currentTime + 10, totalDuration)
                        player?.seek(to: CMTime(seconds: newTime, preferredTimescale: 600))
                        currentTime = newTime
                    } label: {
                        Image(systemName: "forward.fill")
                            .font(.system(size: 28))
                            .foregroundColor(.primary)
                    }
                }

                // Favorite button
                Button {
                    if favManager.isFavorite(song) {
                        favManager.removeFavorite(song)
                    } else {
                        favManager.addFavorite(song)
                    }
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: favManager.isFavorite(song) ? "heart.fill" : "heart")
                            .font(.system(size: 16, weight: .semibold))
                        Text(favManager.isFavorite(song) ? "Remove from Favorites" : "Add to Favorites")
                            .font(.subheadline)
                            .fontWeight(.semibold)
                    }
                    .foregroundColor(favManager.isFavorite(song) ? Color(red: 0.85, green: 0.2, blue: 0.2) : .blue)
                    .padding(.vertical, 14)
                    .padding(.horizontal, 28)
                    .frame(maxWidth: .infinity)
                    .background(
                        favManager.isFavorite(song) ? Color(red: 1.0, green: 0.88, blue: 0.88) : Color(red: 0.88, green: 0.93, blue: 1.0)
                    )
                    .clipShape(Capsule())
                    .shadow(color: .black.opacity(0.08), radius: 6, x: 0, y: 3)
                }
                .padding(.horizontal)
            }
            .padding(.vertical)
        }
        .navigationTitle("Now Playing")
        .navigationBarTitleDisplayMode(.inline)
        .onDisappear {
            player?.pause()
            playbackTimer?.invalidate()
        }
    }

    private func startTimer() {
        playbackTimer?.invalidate()
        playbackTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
            currentTime = player?.currentTime().seconds ?? 0
        }
    }

    private func formatTime(_ seconds: Double) -> String {
        guard !seconds.isNaN && !seconds.isInfinite else { return "0:00" }
        let mins = Int(seconds) / 60
        let secs = Int(seconds) % 60
        return String(format: "%d:%02d", mins, secs)
    }
}
