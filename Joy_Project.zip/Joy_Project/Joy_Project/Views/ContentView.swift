//
//  ContentView.swift
//  Joy_Project
//
//  Created by etud on 08/06/2026.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            SongListView()
                .tabItem { Label("All", systemImage: "music.note") }
            FavoritesView()
                .tabItem { Label("Favorites", systemImage: "heart.fill") }
        }
    }
}
