//
//  SongRowView.shift.swift
//  Joy_Project
//
//  Created by etud on 09/06/2026.
//
import SwiftUI

struct SongRowView: View {
    let song: Song
    @EnvironmentObject var favManager: FavoritesManager

    var body: some View {
        HStack(spacing: 12) {
            // Red minus
            Button {
                favManager.remove(song: song)
            } label: {
                Image(systemName: "minus.circle.fill")
                    .foregroundColor(.red)
                    .font(.title2)
            }
            .buttonStyle(.plain)

            // Title + artist
            VStack(alignment: .leading, spacing: 2) {
                Text(song.title)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .multilineTextAlignment(.leading)
                Text("by \(song.artist)")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .frame(width: 90, alignment: .leading)

            // Artwork
            AsyncImage(url: URL(string: song.artworkURL)) { image in
                image.resizable().scaledToFill()
            } placeholder: {
                Color.gray.opacity(0.3)
            }
            .frame(width: 60, height: 60)
            .cornerRadius(8)
            .clipped()

            Spacer()

            // Heart
            Button {
                favManager.toggleFavorite(song)
            } label: {
                Image(systemName: favManager.isFavorite(song) ? "heart.fill" : "heart")
                    .foregroundColor(favManager.isFavorite(song) ? .red : .gray)
            }
            .buttonStyle(.plain)

            // Navigate to detail
            NavigationLink(destination: SongDetailView(song: song).environmentObject(favManager)) {
                Image(systemName: "chevron.right")
                    .foregroundColor(.gray)
                    .font(.caption)
            }
            .buttonStyle(.plain)

            // Reorder
            Image(systemName: "line.3.horizontal")
                .foregroundColor(.gray)
                .font(.caption)
        }
        .padding(.vertical, 6)
        .padding(.horizontal, 4)
    }
}
