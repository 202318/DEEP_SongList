//
//  SongListView.swift
//  Joy_Project
//
//  Created by etud on 09/06/2026.
//
import SwiftUI

struct SongListView: View {
    
    @StateObject private var service = MusicService()
    @State private var searchText = ""
    
    var filteredSongs: [Song] {
        if searchText.isEmpty {
            return service.songs
        }
        
        return service.songs.filter {
            $0.title.localizedCaseInsensitiveContains(searchText) ||
            $0.artist.localizedCaseInsensitiveContains(searchText)
        }
    }

    var body: some View {
        NavigationStack {
            
            Group {
                
                if service.isLoading {
                    
                    ProgressView("Loading songs...")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                    
                } else {
                    
                    List {
                        
                        ForEach(filteredSongs) { song in
                            
                            NavigationLink(
                                destination: SongDetailView(song: song)
                            ) {
                                
                                HStack(spacing: 12) {
                                    
                                    AsyncImage(
                                        url: URL(string: song.artworkURL)
                                    ) { image in
                                        
                                        image
                                            .resizable()
                                            .scaledToFill()
                                        
                                    } placeholder: {
                                        
                                        Color.gray.opacity(0.3)
                                    }
                                    .frame(width: 56, height: 56)
                                    .cornerRadius(8)
                                    .clipped()
                                    
                                    VStack(
                                        alignment: .leading,
                                        spacing: 4
                                    ) {
                                        
                                        Text(song.title)
                                            .font(.headline)
                                            .lineLimit(1)
                                        
                                        Text(song.artist)
                                            .font(.subheadline)
                                            .foregroundColor(.secondary)
                                            .lineLimit(1)
                                    }
                                }
                                .padding(.vertical, 4)
                            }
                        }
                        .onDelete { offsets in
                            service.deleteSong(at: offsets)
                        }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("All Tracks")
            .searchable(
                text: $searchText,
                prompt: "Search Apple Music"
            )
            .onSubmit(of: .search) {
                service.searchSongs(term: searchText)
            }
            .onAppear {
                if service.songs.isEmpty {
                    service.fetchSongs()
                }
            }
        }
    }
}
